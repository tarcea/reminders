declare namespace NodeJS {
	export interface ProcessEnv {
		REACT_APP_PUBLIC_URL: string;
	}
}
