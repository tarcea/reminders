import { RoomName, UserName } from "../../types"

export type DataAddUserInRoom = {
  userName: UserName;
  roomId: RoomName;
}
